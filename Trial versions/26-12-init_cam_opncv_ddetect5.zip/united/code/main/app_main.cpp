#include <stdio.h>

//internal includes
#include "detect_wrapper.cpp"
#include "opencv_wrapper.cpp"



extern "C" void app_main(void)
{
    if(ESP_OK != app_camera_init()) {
        return;
    }

    //take image
    camera_fb_t *fb = esp_camera_fb_get();
    
    //check the cv app
    app_cv(fb); //todo: only a test for open cv

    //get the basic 5 points
    std::vector<int> points = detect_5_points();

    //try to cannt one image
    bool res = canny_image(fb);


    //esp_camera_fb_return(fb);
    
}