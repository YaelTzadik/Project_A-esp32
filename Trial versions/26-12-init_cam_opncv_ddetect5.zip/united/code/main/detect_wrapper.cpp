#include <stdio.h>
#include "image.hpp"
#include "human_face_detect_msr01.hpp"
#include "human_face_detect_mnp01.hpp"
#include "dl_tool.hpp"


std::vector<int> detect_5_points()
{
    dl::tool::Latency latency;

    // initialize
    HumanFaceDetectMSR01 s1(0.1F, 0.5F, 10, 0.2F);
    HumanFaceDetectMNP01 s2(0.5F, 0.3F, 5);

    // inference
    latency.start();

    std::list<dl::detect::result_t> &candidates = s1.infer((uint8_t *)IMAGE_ELEMENT, {IMAGE_HEIGHT, IMAGE_WIDTH, IMAGE_CHANNEL});
    std::list<dl::detect::result_t> &results = s2.infer((uint8_t *)IMAGE_ELEMENT, {IMAGE_HEIGHT, IMAGE_WIDTH, IMAGE_CHANNEL}, candidates);

    latency.end();
    latency.print("Inference latency");

    // display
    std::vector<int> keys;
    int i = 0;
    for (std::list<dl::detect::result_t>::iterator prediction = results.begin(); prediction != results.end(); prediction++, i++)
    {
        printf("[%d] score: %f, box: [%d, %d, %d, %d]\n", i, prediction->score, prediction->box[0], prediction->box[1], prediction->box[2], prediction->box[3]);
        printf("    left eye: (%3d, %3d), ", prediction->keypoint[0], prediction->keypoint[1]);
        printf("right eye: (%3d, %3d)\n", prediction->keypoint[6], prediction->keypoint[7]);
        printf("    nose: (%3d, %3d)\n", prediction->keypoint[4], prediction->keypoint[5]);
        printf("    mouth left: (%3d, %3d), ", prediction->keypoint[2], prediction->keypoint[3]);
        printf("mouth right: (%3d, %3d)\n\n", prediction->keypoint[8], prediction->keypoint[9]);
        // todo:insert points
    }

    return keys;
}

/*void get_edge_img()
{
    
    Mat inputImage(IMAGE_HEIGHT, IMAGE_WIDTH, CV_8UC2, (uint8_t *)IMAGE_ELEMENT); // rgb565 is 2 channels of 8-bit unsigned

    cvtColor(inputImage, inputImage, COLOR_BGR5652GRAY);
    // Reduce noise with a kernel 3x3
    blur(inputImage, inputImage, Size(3, 3));
    // Apply the canny edges detector with:
     //- low threshold = 50
     * - high threshold = 4x low
     * - sobel kernel size = 3x3
     //
    int lowThresh = 40;
    int kernSize = 3;
    Canny(inputImage, inputImage, lowThresh, 4 * lowThresh, kernSize);
    // input image has the edsges
    printf("done making eggplants\n");
}   */