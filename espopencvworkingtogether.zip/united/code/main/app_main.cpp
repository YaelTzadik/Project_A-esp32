#include <stdio.h>

//internal includes
#include "detect_wrapper.cpp"
#include "hello_opencv.cpp"


extern "C" void app_main(void)
{
    std::vector<int> points = detect_5_points();
    app_cv();
}