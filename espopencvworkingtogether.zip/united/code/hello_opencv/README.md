# Esp32 Hello OpenCV

This is a basic example to test that OpenCV works correctly on the ESP32. The project only creates some matrices and apply basic operations on them.
